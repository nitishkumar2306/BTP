sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.sap.salesinventorymanagementapp.controller.app",{onInit(){}})});
//# sourceMappingURL=app.controller.js.map